<?php
	$conexion = new mysqli("localhost", "root", "", "global_web");
?>