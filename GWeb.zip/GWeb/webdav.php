<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_webdav = $_POST['usuario_webdav'];
    $clave_webdav = $_POST['clave_webdav'];

    if ($usuario_webdav === 'tu_usuario_webdav' && $clave_webdav === 'tu_clave_webdav') {
        
    	require_once('tcpdf/tcpdf.php');
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

	    $pdf->SetCreator(PDF_CREATOR);
	    $pdf->SetAuthor('Tu Nombre');
	    $pdf->SetTitle('PDF Generado con TCPDF');
	    $pdf->SetSubject('Ejemplo de generación de PDF utilizando TCPDF');
	    $pdf->SetKeywords('TCPDF, PDF, ejemplo, PHP');

	    $pdf->AddPage();

	    $pdf->SetFont('helvetica', 'B', 16);
	    $pdf->Cell(0, 10, '¡Hola, este es un PDF generado con TCPDF!', 0, 1, 'C');

	    $filename = 'pdf_'.date('YmdHis').'.pdf';
	    $pdfContent = $pdf->Output('', 'S');
	    $webdavUrl = 'http://10.0.0.6/';
	    $webdavPath = 'webdav/' . $filename;

	    $webdavUsername = 'Krozz';
	    $webdavPassword = '1234';

	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_URL, $webdavUrl . $webdavPath);
	    curl_setopt($curl, CURLOPT_USERPWD, $webdavUsername . ':' . $webdavPassword);
	    curl_setopt($curl, CURLOPT_PUT, true);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_INFILESIZE, strlen($pdfContent));
	    curl_setopt($curl, CURLOPT_INFILE, fopen('data://text/plain;base64,' . base64_encode($pdfContent), 'r'));

	    $response = curl_exec($curl);
	    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

	    curl_close($curl);

	    if ($httpCode === 201) {
	    
		header("Location: " . $webdavUrl . $webdavPath);
		exit();
	    } 
	    
	    else {
	    
		echo "Error al enviar el archivo a WEBDAV";
	    }
    } 
    
    else {
        echo 'Credenciales de WEBDAV incorrectas.';
    }
}
?>