alert('El campo nombre DEBE contener al menos 3 caracteres validos');
window.history.back();
