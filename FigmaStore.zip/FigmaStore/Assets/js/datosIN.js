alert('El campo nombre tiene caracteres NO validos');
window.history.back();
