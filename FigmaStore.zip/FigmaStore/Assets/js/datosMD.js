alert('El campo descripcion DEBE contener al menos 3 caracteres validos');
window.history.back();
