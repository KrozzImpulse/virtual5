alert('El campo descripcion NO debe comenzar por un espacio');
window.history.back();
