alert('El campo telefono DEBE contener al menos 10 caracteres validos');
window.history.back();
