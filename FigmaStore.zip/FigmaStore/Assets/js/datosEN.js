alert('El campo nombre NO debe comenzar por un espacio');
window.history.back();
