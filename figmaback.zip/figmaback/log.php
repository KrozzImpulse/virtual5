<?php
//Agregar el alter table para modificar el producto

include 'conexion.php';
$client = $conexion=mysqli_connect("localhost","root","","figma2")
or die("No se puede conectar con el servidor");

mysqli_select_db($conexion, "figma2")
or die("No se puede conectar a la base de datos.")

print($client->leerLog(array("usuario"=>$usuarioMostrado))->resultado);



?>
